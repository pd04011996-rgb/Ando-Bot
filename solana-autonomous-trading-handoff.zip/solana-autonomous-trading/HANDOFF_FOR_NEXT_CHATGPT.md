# Handoff: Solana Autonomous Trading System

## Purpose
Continue this project in a new ChatGPT conversation. This file captures the user-provided requirements, architectural review, decisions, current scaffold contents, verification status, and next milestone. It contains a concise engineering rationale and project context, not private hidden chain-of-thought.

## User's project goal
Build an autonomous Solana trading system with:
- Solana Anchor on-chain program
- Node.js backend with 24/7 DEX scanning, anti-rug verification, Jupiter/Jito execution, SQLite WAL initially and PostgreSQL later
- AI manager for market regime classification, risk sizing, position monitoring, and dynamic exits
- Next.js App Router dashboard with portfolio/PnL/telemetry/manual controls
- Telegram Mini App and bot with `/status`, `/pause`, `/panic`
- React Native/Expo client, push notifications, iOS Live Activities/Dynamic Island
- Independent multi-layer emergency killswitch

## Defaults from the user
- Devnet first; mainnet only behind explicit config.
- Bot hot wallet with hard-capped balance; sweep profits to cold wallet.
- No user private keys on backend.
- Never put raw private keys in `.env` or Git.
- Use encrypted local development keystore and KMS/HSM-style signer interface in production.
- pnpm workspaces + Turborepo.
- Workspace areas: `programs/`, `apps/backend`, `apps/web`, `apps/tma`, `apps/mobile`, `packages/shared`, `packages/risk`, `packages/ai`; the generated scaffold also includes `apps/killswitch`.
- Build order: monorepo/CI, Anchor program, backend core, killswitch, AI manager, web, Telegram/TMA, mobile/Live Activities.

## Non-negotiable safety requirements
- Hard limits in backend and on-chain program: max position size, max daily loss, max open positions, max slippage.
- AI may tighten limits only, never bypass or loosen them.
- Independent killswitch triggers: daily-loss cap, RPC failure streak, on-chain/database drift, manual panic.
- On trigger: halt scanner, cancel pending orders, attempt position exits, lock state until human unlock; never claim an exit succeeded until confirmed on-chain.
- Anchor account validation: owner, signer, PDA seeds/bump, `has_one`, constraints, checked math, rent exemption, safe account closure, typed errors, validated CPIs.
- Anti-rug checks: mint authority revoked, freeze authority revoked, LP burned/locked, top-holder concentration below threshold, sell simulation passes, minimum liquidity. Fail closed on RPC errors/ambiguous data.
- Execution: simulate before send, priority fee/slippage caps, optional Jito bundles, idempotent order IDs and retry-safe transaction tracking.
- Persistence: SQLite WAL, atomic transactions, write-ahead intent before each trade.
- Telegram: user-ID allowlist, server-side initData signature validation, rate limits, confirmation for destructive actions.
- Clearly state memecoin trading is adversarial and there is no profit guarantee.

## Architectural review already provided
1. Eight subsystems should be built in milestones with test gates.
2. On-chain program cannot independently verify off-chain market facts; use explicit trusted-input/state models.
3. Signer abstraction, encrypted dev keystore, production KMS/HSM adapter, strict authorization.
4. Token verification must include Token-2022 extensions, token program ownership, evidence provenance, liquidity and holder concentration—not just mint/freeze authority.
5. Durable idempotency, write-ahead intent, signature tracking, reconciliation after ambiguous RPC outcomes.
6. Simulate, cap priority fees, bounded retries; Jito is Solana-specific; Flashbots is primarily Ethereum.
7. Killswitch must be separate and durable; do not report positions closed until confirmed.
8. SQLite WAL + single-writer discipline first; PostgreSQL transactional locking before horizontal scaling.
9. AI is advisory; deterministic risk controls can reject any trade.
10. Validate Telegram initData on server and authorize every privileged API; do not trust client-reported PnL/wallet/permissions.
11. Push notifications and Live Activities are best-effort UI, not safety infrastructure.
12. Pin tool versions, strict TypeScript, Rust checks, dependency scans, lockfile.
13. Add health checks, bounded retries, audit logs, secret redaction, and explicit mainnet approval gate.
14. This assistant can generate files/commands but cannot directly operate the user's local VS Code or GitHub without an authorized integration.
15. Start with monorepo, shared contracts, risk primitives, CI; no real-fund execution until security controls are validated.

## Generated milestone 1 scaffold
The ZIP includes a generated monorepo with:
- root pnpm workspace and Turborepo configuration
- strict TypeScript base config and ESLint flat config
- GitHub Actions CI workflow
- Docker Compose PostgreSQL service for local integration work
- `.env.example` and `.gitignore` excluding `.env`, key files, keystores, wallets, DB files
- `Anchor.toml` and minimal Rust Anchor crate
- `packages/shared`: Zod runtime config, mainnet gate, typed signer interface, audit event and trade intent schema
- `packages/risk`: deterministic risk limit validation and tests
- `packages/ai`: conservative rule-based market regime classifier and tests
- `apps/backend`: Fastify health/readiness server; explicitly no trading or signing
- `apps/killswitch`: monitor-only state-file process; not a full operational killswitch
- `apps/web`: Next.js read-only dashboard shell
- `apps/tma`: Next.js read-only Mini App shell
- `apps/mobile`: Expo informational shell
- tests for shared config, risk rules, AI regime classifier, backend health, and killswitch state initialization

## Important current limitations
- The Anchor `initialize` instruction intentionally returns a `MilestoneNotImplemented` error. The vault is not functional.
- No DEX scanner, anti-rug verifier, transaction execution, signer implementation, SQLite persistence, real killswitch actions, Telegram bot/auth, wallet connection, push, or Live Activities are implemented yet.
- Do not present this scaffold as production-ready or as capable of trading.
- Full package installation/build/test was not run in the prior environment because package registry access was unavailable. Run all checks locally and fix any failures before proceeding.
- The project archive was generated at `/mnt/data/solana-autonomous-trading-milestone-1.zip` before this handoff file was added. This new handoff archive includes the handoff document.

## First commands in the new environment
```bash
corepack enable
corepack prepare pnpm@9.15.4 --activate
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm build
cargo check --manifest-path programs/vault/Cargo.toml
```

If `pnpm install` fails due to version/platform issues, fix and record the actual environment/version details rather than assuming tests passed.

## Suggested next milestone
Milestone 2: replace the disabled Anchor scaffold with a properly specified vault/state model and tests. Before writing the implementation, define which actions the vault can actually authorize and what state is verifiable on-chain. Use explicit PDA seeds, account ownership constraints, signer/authority validation, checked arithmetic, safe rent handling, typed errors, and test account-substitution and unauthorized-call failures. Keep trading disabled until tests pass.

## GitHub workflow
The README contains commands to initialize Git, commit, set a GitHub remote, and push. The user must replace the example remote URL and authenticate with GitHub. Do not include secrets or keypair files in commits.
